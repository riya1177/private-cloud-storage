from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker
import datetime

import os
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cloudstorage.db")
SQLALCHEMY_DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class FileMetadata(Base):
    __tablename__ = "files"

    id = Column(Integer, primary_key=True, index=True)
    original_filename = Column(String, index=True)
    encrypted_path = Column(String)
    file_size_bytes = Column(Integer)
    upload_time = Column(DateTime, default=datetime.datetime.utcnow)
    owner = Column(String, default="Pending_OAuth")

    # File usage tracking
    access_count = Column(Integer, default=0)
    last_accessed = Column(DateTime, nullable=True)

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True, nullable=True)
    password_hash = Column(String)
    salt = Column(String)
    two_factor_enabled = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    email = Column(String, index=True)
    token_hash = Column(String, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    expires_at = Column(DateTime, index=True)
    used_at = Column(DateTime, nullable=True)

class OTPRecord(Base):
    __tablename__ = "otp_records"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    email = Column(String, index=True)
    otp_hash = Column(String, index=True)
    purpose = Column(String, default="login") # 'login', 'enable_2fa', 'disable_2fa'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    expires_at = Column(DateTime, index=True)
    attempts = Column(Integer, default=0)
    used_at = Column(DateTime, nullable=True)

class UserSession(Base):
    __tablename__ = "user_sessions"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    token = Column(String, unique=True, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    expires_at = Column(DateTime, index=True)

class SignupVerificationToken(Base):
    __tablename__ = "signup_verification_tokens"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    email = Column(String, index=True)
    token_hash = Column(String, unique=True, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    expires_at = Column(DateTime, index=True)
    used_at = Column(DateTime, nullable=True)

from sqlalchemy import inspect, text

# Generate the database tables when this file runs
Base.metadata.create_all(bind=engine)

# Auto-migrate SQLite schema for missing User columns if database already existed
try:
    with engine.connect() as conn:
        existing_cols = [col['name'] for col in inspect(engine).get_columns('users')]
        if 'email' not in existing_cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN email VARCHAR"))
            print("[DATABASE] Auto-migrated: Added 'email' column to users table.")
        if 'two_factor_enabled' not in existing_cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN two_factor_enabled BOOLEAN DEFAULT 0"))
            print("[DATABASE] Auto-migrated: Added 'two_factor_enabled' column to users table.")

        conn.commit()
except Exception as e:
    print(f"[DATABASE NOTICE] Schema check completed: {e}")