from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.responses import Response, JSONResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
import os
import json
import redis
import datetime
import secrets
from cryptography.fernet import Fernet
from pydantic import BaseModel

# Import database models
from database import SessionLocal, FileMetadata, User, PasswordResetToken, OTPRecord, UserSession, SignupVerificationToken

# Import authentication & security helpers
from auth import verify_user_token, hash_password, verify_password, hash_token

# Import email service
from email_service import send_password_reset_email, send_otp_email, is_smtp_configured

app = FastAPI(title="Cloud Storage Backend")
redis_client = redis.Redis(
    host="localhost",
    port=6379,
    decode_responses=True
)
FREQUENT_FILES_CACHE_TTL = 60
def invalidate_frequently_used_cache(username: str):
    redis_client.delete(f"frequently_used:{username}")
try:
    redis_client.ping()
    print("Redis connected successfully!")
except redis.RedisError:
    print("Redis connection failed!")
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- DATABASE DEPENDENCY ---
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Simulate storage directory
STORAGE_DIR = "storage_pool"
os.makedirs(STORAGE_DIR, exist_ok=True)

# --- ENCRYPTION SETUP ---
KEY_FILE = "secret.key"

def load_or_create_key():
    if not os.path.exists(KEY_FILE):
        key = Fernet.generate_key()
        with open(KEY_FILE, "wb") as key_file:
            key_file.write(key)
    else:
        with open(KEY_FILE, "rb") as key_file:
            key = key_file.read()
    return key

encryption_key = load_or_create_key()
cipher_suite = Fernet(encryption_key)

# --- PYDANTIC REQUEST SCHEMAS ---
class ForgotPasswordRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

class Verify2FARequest(BaseModel):
    username: str
    otp_code: str

class Resend2FARequest(BaseModel):
    username: str
    purpose: str = "login"

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

class Enable2FARequest(BaseModel):
    current_password: str

class Enable2FAConfirm(BaseModel):
    otp_code: str

class Disable2FARequest(BaseModel):
    current_password: str

class Disable2FAConfirm(BaseModel):
    otp_code: str

class SignupOTPRequest(BaseModel):
    username: str
    email: str

class SignupVerifyOTPRequest(BaseModel):
    email: str
    otp_code: str

class SignupCreateAccountRequest(BaseModel):
    username: str
    email: str
    verification_token: str
    password: str


def mask_email(email: str) -> str:
    if not email or "@" not in email:
        return email or ""
    name, domain = email.split("@", 1)
    if len(name) <= 2:
        masked_name = name[0] + "*"
    else:
        masked_name = name[:2] + "*" * (len(name) - 2)
    return f"{masked_name}@{domain}"


@app.get("/")
def read_root():
    return {"message": "Cloud Storage Backend is running!"}

def create_user_session(db: Session, username: str) -> str:
    token_val = secrets.token_hex(32)
    session = UserSession(
        username=username,
        token=token_val,
        expires_at=datetime.datetime.utcnow() + datetime.timedelta(days=7)
    )
    db.add(session)
    db.commit()
    return token_val

# --- TOKEN LOGIN ENDPOINT ---
@app.post("/token")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    login_identifier = form_data.username.strip()
    password = form_data.password.strip()

    if not login_identifier or not password:
        raise HTTPException(status_code=400, detail="Email/Username and password are required")

    # Match user by registered EMAIL or registered USERNAME
    user = db.query(User).filter(
        (User.email.ilike(login_identifier)) | (User.username == login_identifier)
    ).first()

    if not user or not verify_password(password, user.password_hash, user.salt):
        raise HTTPException(status_code=401, detail="Invalid email/username or password")

    # Check 2FA requirement
    if user.two_factor_enabled:
        user_email = user.email

        if not is_smtp_configured():
            raise HTTPException(
                status_code=400,
                detail="Email verification is currently unavailable. Please configure SMTP settings."
            )

        otp_code = f"{secrets.randbelow(1000000):06d}"
        otp_hash = hash_token(otp_code)

        db.query(OTPRecord).filter(
            OTPRecord.username == user.username,
            OTPRecord.purpose == "login",
            OTPRecord.used_at == None
        ).update({"used_at": datetime.datetime.utcnow()})

        new_otp = OTPRecord(
            username=user.username,
            email=user_email,
            otp_hash=otp_hash,
            purpose="login",
            expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
            attempts=0
        )
        db.add(new_otp)
        db.commit()

        email_dispatch = send_otp_email(user_email, otp_code, user.username, purpose="login")
        if not email_dispatch.get("delivered"):
            raise HTTPException(
                status_code=400,
                detail="Unable to send verification email. Please check the email/SMTP configuration."
            )

        return {
            "requires_2fa": True,
            "username": user.username,
            "email": user_email,
            "masked_email": mask_email(user_email),
            "message": f"Two-Step Verification code sent to {mask_email(user_email)}.",
            "smtp_configured": True
        }

    token_val = create_user_session(db, user.username)
    return {"access_token": token_val, "token_type": "bearer", "requires_2fa": False, "username": user.username}


# --- 2FA VERIFICATION ENDPOINT ---
@app.post("/auth/verify-2fa")
async def verify_2fa(
    payload: Verify2FARequest,
    db: Session = Depends(get_db)
):
    username = payload.username.strip()
    otp_code = payload.otp_code.strip()

    if not username or not otp_code:
        raise HTTPException(status_code=400, detail="Username and verification code are required")

    otp_record = db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == "login",
        OTPRecord.used_at == None,
        OTPRecord.expires_at > datetime.datetime.utcnow()
    ).order_by(OTPRecord.id.desc()).first()

    if not otp_record:
        raise HTTPException(status_code=400, detail="Invalid or expired verification code. Please request a new code.")

    if otp_record.attempts >= 5:
        otp_record.used_at = datetime.datetime.utcnow()
        db.commit()
        raise HTTPException(status_code=400, detail="Maximum verification attempts exceeded. Please request a new code.")

    incoming_hash = hash_token(otp_code)
    if incoming_hash != otp_record.otp_hash:
        otp_record.attempts += 1
        db.commit()
        remaining = 5 - otp_record.attempts
        raise HTTPException(status_code=400, detail=f"Invalid verification code. {remaining} attempt(s) remaining.")

    otp_record.used_at = datetime.datetime.utcnow()
    db.commit()

    token_val = create_user_session(db, username)
    return {"access_token": token_val, "token_type": "bearer", "username": username}


# --- RESEND 2FA OTP ENDPOINT ---
@app.post("/auth/resend-2fa-otp")
async def resend_2fa_otp(
    payload: Resend2FARequest,
    db: Session = Depends(get_db)
):
    if not is_smtp_configured():
        raise HTTPException(
            status_code=400,
            detail="Email verification is currently unavailable. Please configure SMTP settings."
        )

    username = payload.username.strip()
    purpose = payload.purpose.strip()

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=400, detail="User account not found")

    latest_otp = db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == purpose
    ).order_by(OTPRecord.id.desc()).first()

    if latest_otp and latest_otp.created_at:
        seconds_since = (datetime.datetime.utcnow() - latest_otp.created_at).total_seconds()
        if seconds_since < 30:
            cooldown_left = int(30 - seconds_since)
            raise HTTPException(status_code=429, detail=f"Please wait {cooldown_left} seconds before requesting a new code.")

    otp_code = f"{secrets.randbelow(1000000):06d}"
    otp_hash = hash_token(otp_code)
    user_email = user.email

    db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == purpose,
        OTPRecord.used_at == None
    ).update({"used_at": datetime.datetime.utcnow()})

    new_otp = OTPRecord(
        username=username,
        email=user_email,
        otp_hash=otp_hash,
        purpose=purpose,
        expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
        attempts=0
    )
    db.add(new_otp)
    db.commit()

    email_dispatch = send_otp_email(user_email, otp_code, username, purpose=purpose)
    if not email_dispatch.get("delivered"):
        raise HTTPException(
            status_code=400,
            detail="Unable to send verification email. Please check the email/SMTP configuration."
        )

    return {
        "status": "success",
        "message": "Verification code resent.",
        "smtp_configured": True
    }


# --- FORGOT PASSWORD ENDPOINT ---
@app.post("/auth/forgot-password")
async def forgot_password(
    payload: ForgotPasswordRequest,
    db: Session = Depends(get_db)
):
    if not is_smtp_configured():
        raise HTTPException(
            status_code=400,
            detail="Email verification is currently unavailable. Please configure SMTP settings."
        )

    email = payload.email.strip().lower()

    if not email or "@" not in email or "." not in email:
        raise HTTPException(status_code=400, detail="Please enter a valid email address.")

    user = db.query(User).filter(User.email.ilike(email)).first()

    if user and user.email:
        raw_token = secrets.token_urlsafe(32)
        token_hash = hash_token(raw_token)

        db.query(PasswordResetToken).filter(
            PasswordResetToken.username == user.username,
            PasswordResetToken.used_at == None
        ).update({"used_at": datetime.datetime.utcnow()})

        reset_record = PasswordResetToken(
            username=user.username,
            email=user.email,
            token_hash=token_hash,
            expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=20),
            used_at=None
        )
        db.add(reset_record)
        db.commit()

        email_dispatch = send_password_reset_email(user.email, raw_token, user.username)
        if not email_dispatch.get("delivered"):
            raise HTTPException(
                status_code=400,
                detail="Unable to send password reset email. Please check the SMTP configuration."
            )

    return {
        "status": "success",
        "message": "If an account exists for this email, a password reset link has been sent.",
        "smtp_configured": True
    }


# --- RESET PASSWORD ENDPOINT ---
@app.post("/auth/reset-password")
async def reset_password(
    payload: ResetPasswordRequest,
    db: Session = Depends(get_db)
):
    raw_token = payload.token.strip()
    new_pass = payload.new_password.strip()

    if not raw_token:
        raise HTTPException(status_code=400, detail="Reset token is required")

    if len(new_pass) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters long")

    token_hash = hash_token(raw_token)
    token_record = db.query(PasswordResetToken).filter(
        PasswordResetToken.token_hash == token_hash,
        PasswordResetToken.used_at == None,
        PasswordResetToken.expires_at > datetime.datetime.utcnow()
    ).first()

    if not token_record:
        raise HTTPException(status_code=400, detail="Invalid or expired password reset link.")

    user = db.query(User).filter(User.username == token_record.username).first()
    if not user:
        raise HTTPException(status_code=400, detail="User account not found.")

    if verify_password(new_pass, user.password_hash, user.salt):
        raise HTTPException(status_code=400, detail="New password cannot be identical to your current password.")

    new_hash, new_salt = hash_password(new_pass)
    user.password_hash = new_hash
    user.salt = new_salt
    token_record.used_at = datetime.datetime.utcnow()
    db.commit()

    return {"status": "success", "message": "Password updated successfully. You can now log in with your new password."}


# --- NEW USER SIGNUP ENDPOINTS ---
@app.post("/auth/signup/request-otp")
async def signup_request_otp(
    payload: SignupOTPRequest,
    db: Session = Depends(get_db)
):
    username = payload.username.strip()
    email = payload.email.strip().lower()

    if not username or len(username) < 3:
        raise HTTPException(status_code=400, detail="Please enter a valid name or username (at least 3 characters).")

    if not email or "@" not in email or "." not in email:
        raise HTTPException(status_code=400, detail="Please enter a valid email address.")

    # Check for duplicate username
    existing_user_by_name = db.query(User).filter(User.username == username).first()
    if existing_user_by_name:
        raise HTTPException(status_code=400, detail="This name/username is already registered. Please log in or use a different name.")

    # Check for duplicate email
    existing_user_by_email = db.query(User).filter(User.email.ilike(email)).first()
    if existing_user_by_email:
        raise HTTPException(status_code=400, detail="This email address is already registered. Please log in instead.")

    if not is_smtp_configured():
        raise HTTPException(
            status_code=400,
            detail="Email verification is currently unavailable. Please configure SMTP settings."
        )

    # Cooldown check (30s)
    latest_otp = db.query(OTPRecord).filter(
        OTPRecord.email == email,
        OTPRecord.purpose == "signup"
    ).order_by(OTPRecord.id.desc()).first()

    if latest_otp and latest_otp.created_at:
        seconds_since = (datetime.datetime.utcnow() - latest_otp.created_at).total_seconds()
        if seconds_since < 30:
            cooldown_left = int(30 - seconds_since)
            raise HTTPException(status_code=429, detail=f"Please wait {cooldown_left} seconds before requesting a new code.")

    # Invalidate previous unused signup OTPs for this email
    db.query(OTPRecord).filter(
        OTPRecord.email == email,
        OTPRecord.purpose == "signup",
        OTPRecord.used_at == None
    ).update({"used_at": datetime.datetime.utcnow()})

    otp_code = f"{secrets.randbelow(1000000):06d}"
    otp_hash = hash_token(otp_code)

    new_otp = OTPRecord(
        username=username,
        email=email,
        otp_hash=otp_hash,
        purpose="signup",
        expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
        attempts=0
    )
    db.add(new_otp)
    db.commit()

    email_dispatch = send_otp_email(email, otp_code, username, purpose="signup")
    if not email_dispatch.get("delivered"):
        raise HTTPException(
            status_code=400,
            detail="Unable to send verification email. Please check the email/SMTP configuration."
        )

    return {
        "status": "success",
        "message": f"Verification code sent to {mask_email(email)}.",
        "email": email,
        "masked_email": mask_email(email),
        "smtp_configured": True
    }


@app.post("/auth/signup/verify-otp")
async def signup_verify_otp(
    payload: SignupVerifyOTPRequest,
    db: Session = Depends(get_db)
):
    email = payload.email.strip().lower()
    otp_code = payload.otp_code.strip()

    if not email or not otp_code:
        raise HTTPException(status_code=400, detail="Email and verification code are required.")

    otp_record = db.query(OTPRecord).filter(
        OTPRecord.email == email,
        OTPRecord.purpose == "signup",
        OTPRecord.used_at == None,
        OTPRecord.expires_at > datetime.datetime.utcnow()
    ).order_by(OTPRecord.id.desc()).first()

    if not otp_record:
        raise HTTPException(status_code=400, detail="Invalid or expired verification code. Please request a new code.")

    if otp_record.attempts >= 5:
        otp_record.used_at = datetime.datetime.utcnow()
        db.commit()
        raise HTTPException(status_code=400, detail="Maximum verification attempts exceeded. Please request a new code.")

    if hash_token(otp_code) != otp_record.otp_hash:
        otp_record.attempts += 1
        db.commit()
        remaining = 5 - otp_record.attempts
        raise HTTPException(status_code=400, detail=f"Invalid verification code. {remaining} attempt(s) remaining.")

    otp_record.used_at = datetime.datetime.utcnow()

    # Generate single-use, short-lived, cryptographically secure verification_token bound to username & email
    raw_token = secrets.token_urlsafe(32)
    token_hash = hash_token(raw_token)

    # Clean previous unused signup verification tokens for this email/username
    db.query(SignupVerificationToken).filter(
        SignupVerificationToken.email == email,
        SignupVerificationToken.used_at == None
    ).update({"used_at": datetime.datetime.utcnow()})

    signup_token_rec = SignupVerificationToken(
        username=otp_record.username,
        email=email,
        token_hash=token_hash,
        expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=15),
        used_at=None
    )
    db.add(signup_token_rec)
    db.commit()

    return {
        "status": "success",
        "message": "Email verified successfully.",
        "verification_token": raw_token
    }


@app.post("/auth/signup/create-account")
async def signup_create_account(
    payload: SignupCreateAccountRequest,
    db: Session = Depends(get_db)
):
    username = payload.username.strip()
    email = payload.email.strip().lower()
    raw_token = payload.verification_token.strip()
    password = payload.password.strip()

    if not username or not email or not raw_token or not password:
        raise HTTPException(status_code=400, detail="All fields are required.")

    if len(password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters long.")

    token_hash = hash_token(raw_token)
    token_rec = db.query(SignupVerificationToken).filter(
        SignupVerificationToken.token_hash == token_hash,
        SignupVerificationToken.used_at == None,
        SignupVerificationToken.expires_at > datetime.datetime.utcnow()
    ).first()

    if not token_rec or token_rec.email.lower() != email or token_rec.username != username:
        raise HTTPException(status_code=400, detail="Invalid, expired, or mismatched verification session. Please verify email again.")

    # Re-verify uniqueness before inserting into DB
    if db.query(User).filter(User.username == username).first():
        raise HTTPException(status_code=400, detail="Username is already registered.")

    if db.query(User).filter(User.email.ilike(email)).first():
        raise HTTPException(status_code=400, detail="Email address is already registered.")

    # Hash password using standard PBKDF2-HMAC-SHA256 scheme
    pwd_hash, pwd_salt = hash_password(password)

    new_user = User(
        username=username,
        email=email,
        password_hash=pwd_hash,
        salt=pwd_salt,
        two_factor_enabled=False
    )
    db.add(new_user)

    # Mark verification token used
    token_rec.used_at = datetime.datetime.utcnow()

    db.commit()

    return {
        "status": "success",
        "message": "Account created successfully. Please log in."
    }


# --- 2FA SETTINGS MANAGEMENT ENDPOINTS ---
@app.get("/auth/2fa-status")
async def get_2fa_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    username = current_user.get("username")
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User account not found")

    user_email = user.email or ""
    return {
        "two_factor_enabled": bool(user.two_factor_enabled),
        "email": user_email,
        "masked_email": mask_email(user_email)
    }


@app.post("/auth/2fa/enable-request")
async def enable_2fa_request(
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    if not is_smtp_configured():
        raise HTTPException(
            status_code=400,
            detail="Email verification is currently unavailable. Please configure SMTP settings."
        )

    username = current_user.get("username")

    user = db.query(User).filter(User.username == username).first()
    if not user or not user.email:
        raise HTTPException(status_code=404, detail="User account or registered email not found")

    user_email = user.email

    otp_code = f"{secrets.randbelow(1000000):06d}"
    otp_hash = hash_token(otp_code)

    db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == "enable_2fa",
        OTPRecord.used_at == None
    ).update({"used_at": datetime.datetime.utcnow()})

    new_otp = OTPRecord(
        username=username,
        email=user_email,
        otp_hash=otp_hash,
        purpose="enable_2fa",
        expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
        attempts=0
    )
    db.add(new_otp)
    db.commit()

    email_dispatch = send_otp_email(user_email, otp_code, username, purpose="enable_2fa")
    if not email_dispatch.get("delivered"):
        raise HTTPException(
            status_code=400,
            detail="Unable to send verification email. Please check the email/SMTP configuration."
        )

    return {
        "status": "success",
        "message": f"Verification code sent to {mask_email(user_email)}.",
        "email": user_email,
        "masked_email": mask_email(user_email),
        "smtp_configured": True
    }


@app.post("/auth/2fa/enable-confirm")
async def enable_2fa_confirm(
    payload: Enable2FAConfirm,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    username = current_user.get("username")
    otp_code = payload.otp_code.strip()

    otp_record = db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == "enable_2fa",
        OTPRecord.used_at == None,
        OTPRecord.expires_at > datetime.datetime.utcnow()
    ).order_by(OTPRecord.id.desc()).first()

    if not otp_record:
        raise HTTPException(status_code=400, detail="Invalid or expired verification code.")

    if otp_record.attempts >= 5:
        otp_record.used_at = datetime.datetime.utcnow()
        db.commit()
        raise HTTPException(status_code=400, detail="Maximum verification attempts exceeded. Please request a new code.")

    if hash_token(otp_code) != otp_record.otp_hash:
        otp_record.attempts += 1
        db.commit()
        remaining = 5 - otp_record.attempts
        raise HTTPException(status_code=400, detail=f"Invalid verification code. {remaining} attempt(s) remaining.")

    otp_record.used_at = datetime.datetime.utcnow()
    user = db.query(User).filter(User.username == username).first()
    if user:
        user.two_factor_enabled = True
    db.commit()

    return {"status": "success", "message": "Two-Step Verification enabled successfully."}


@app.post("/auth/2fa/disable-request")
async def disable_2fa_request(
    payload: Disable2FARequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    username = current_user.get("username")
    curr_pass = payload.current_password.strip()

    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(curr_pass, user.password_hash, user.salt):
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    if not is_smtp_configured():
        raise HTTPException(
            status_code=400,
            detail="Email verification is currently unavailable. Please configure SMTP settings."
        )

    user_email = user.email

    otp_code = f"{secrets.randbelow(1000000):06d}"
    otp_hash = hash_token(otp_code)

    db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == "disable_2fa",
        OTPRecord.used_at == None
    ).update({"used_at": datetime.datetime.utcnow()})

    new_otp = OTPRecord(
        username=username,
        email=user_email,
        otp_hash=otp_hash,
        purpose="disable_2fa",
        expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
        attempts=0
    )
    db.add(new_otp)
    db.commit()

    email_dispatch = send_otp_email(user_email, otp_code, username, purpose="disable_2fa")
    if not email_dispatch.get("delivered"):
        raise HTTPException(
            status_code=400,
            detail="Unable to send verification email. Please check the email/SMTP configuration."
        )

    return {
        "status": "success",
        "message": f"Verification code sent to {mask_email(user_email)}.",
        "email": user_email,
        "masked_email": mask_email(user_email),
        "smtp_configured": True
    }


@app.post("/auth/2fa/disable-confirm")
async def disable_2fa_confirm(
    payload: Disable2FAConfirm,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    username = current_user.get("username")
    otp_code = payload.otp_code.strip()

    otp_record = db.query(OTPRecord).filter(
        OTPRecord.username == username,
        OTPRecord.purpose == "disable_2fa",
        OTPRecord.used_at == None,
        OTPRecord.expires_at > datetime.datetime.utcnow()
    ).order_by(OTPRecord.id.desc()).first()

    if not otp_record:
        raise HTTPException(status_code=400, detail="Invalid or expired verification code.")

    if otp_record.attempts >= 5:
        otp_record.used_at = datetime.datetime.utcnow()
        db.commit()
        raise HTTPException(status_code=400, detail="Maximum verification attempts exceeded. Please request a new code.")

    if hash_token(otp_code) != otp_record.otp_hash:
        otp_record.attempts += 1
        db.commit()
        remaining = 5 - otp_record.attempts
        raise HTTPException(status_code=400, detail=f"Invalid verification code. {remaining} attempt(s) remaining.")

    otp_record.used_at = datetime.datetime.utcnow()
    user = db.query(User).filter(User.username == username).first()
    if user:
        user.two_factor_enabled = False
    db.commit()

    return {"status": "success", "message": "Two-Step Verification has been disabled."}


# --- CHANGE PASSWORD ENDPOINT ---
@app.patch("/auth/change-password")
async def change_password(
    payload: ChangePasswordRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    username = current_user.get("username")
    curr_pass = payload.current_password.strip()
    new_pass = payload.new_password.strip()

    if not curr_pass or not new_pass:
        raise HTTPException(status_code=400, detail="Current password and new password are required")

    if len(new_pass) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters long")

    if curr_pass == new_pass:
        raise HTTPException(status_code=400, detail="New password cannot be identical to current password")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User account not found")

    if not verify_password(curr_pass, user.password_hash, user.salt):
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    new_hash, new_salt = hash_password(new_pass)
    user.password_hash = new_hash
    user.salt = new_salt
    db.commit()

    return {"status": "success", "message": "Password changed successfully"}

# --------------------------------------------

@app.post("/upload")
async def upload_file(
    file: UploadFile = File(...), 
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token) # <--- The security lock!
):
    file_location = f"{STORAGE_DIR}/{file.filename}.encrypted"
    
    # 1. Read and encrypt
    raw_data = await file.read()
    file_size = len(raw_data)
    encrypted_data = cipher_suite.encrypt(raw_data)
    
    # 2. Save to disk
    with open(file_location, "wb+") as file_object:
        file_object.write(encrypted_data)
        
    # 3. Save Metadata to Database using the authenticated user's name
    db_file = FileMetadata(
        original_filename=file.filename,
        encrypted_path=file_location,
        file_size_bytes=file_size,
        owner=current_user["username"] # Now uses "Riya_Admin" instead of "Pending_OAuth"
    )
    db.add(db_file)
    db.commit()
    db.refresh(db_file)
    
    invalidate_frequently_used_cache(current_user["username"])
        
    return {
        "filename": file.filename,
        "status": "success",
        "database_id": db_file.id,
        "owner": current_user["username"],
        "message": f"File encrypted, saved securely, and metadata logged!"
    }

@app.get("/download/{filename}")
async def download_file(
    filename: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    # Find the file belonging to the logged-in user
    db_file = db.query(FileMetadata).filter(
        FileMetadata.original_filename == filename,
        FileMetadata.owner == current_user["username"]
    ).first()

    if not db_file:
        raise HTTPException(
            status_code=404,
            detail="File not found"
        )

    file_location = db_file.encrypted_path

    if not os.path.exists(file_location):
        raise HTTPException(
            status_code=404,
            detail="File not found on server"
        )

    # Update usage information
    db_file.access_count = (db_file.access_count or 0) + 1
    db_file.last_accessed = datetime.datetime.utcnow()

    db.commit()
    invalidate_frequently_used_cache(current_user["username"])
    # Read encrypted file
    with open(file_location, "rb") as file_object:
        encrypted_data = file_object.read()

    # Decrypt file
    try:
        decrypted_data = cipher_suite.decrypt(encrypted_data)
    except Exception:
        raise HTTPException(
            status_code=500,
            detail="Failed to decrypt the file. Key might be invalid."
        )

    return Response(
        content=decrypted_data,
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )
#LIST USER FILES
@app.get("/files")
async def list_files(
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    files = db.query(FileMetadata).filter(
        FileMetadata.owner == current_user["username"]
    ).order_by(FileMetadata.upload_time.desc()).all()

    return [
        {
            "id": file.id,
            "filename": file.original_filename,
            "size": file.file_size_bytes,
            "uploaded_at": file.upload_time,
            "owner": file.owner
        }
        for file in files
    ]
# --- DELETE FILE ---
@app.delete("/files/{file_id}")
async def delete_file(
    file_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    db_file = db.query(FileMetadata).filter(
        FileMetadata.id == file_id,
        FileMetadata.owner == current_user["username"]
    ).first()

    if not db_file:
        raise HTTPException(
            status_code=404,
            detail="File not found"
        )

    # Delete encrypted file from storage
    if os.path.exists(db_file.encrypted_path):
        os.remove(db_file.encrypted_path)

    # Delete metadata from database
    db.delete(db_file)
    db.commit()
    
    invalidate_frequently_used_cache(current_user["username"])
    return {
        "status": "success",
        "message": "File deleted successfully"
    }
# --- RENAME FILE ---
@app.patch("/files/{file_id}")
async def rename_file(
    file_id: int,
    new_filename: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    db_file = db.query(FileMetadata).filter(
        FileMetadata.id == file_id,
        FileMetadata.owner == current_user["username"]
    ).first()

    if not db_file:
        raise HTTPException(
            status_code=404,
            detail="File not found"
        )

    # Remove any path information from the filename
    new_filename = os.path.basename(new_filename).strip()

    if not new_filename:
        raise HTTPException(
            status_code=400,
            detail="Filename cannot be empty"
        )

    old_path = db_file.encrypted_path
    new_path = f"{STORAGE_DIR}/{new_filename}.encrypted"

    # Prevent overwriting another physical file
    if os.path.exists(new_path) and new_path != old_path:
        raise HTTPException(
            status_code=409,
            detail="A file with this name already exists"
        )

    # Rename encrypted file on disk
    if os.path.exists(old_path):
        os.rename(old_path, new_path)

    # Update database
    db_file.original_filename = new_filename
    db_file.encrypted_path = new_path

    db.commit()
    db.refresh(db_file)
    
    invalidate_frequently_used_cache(current_user["username"])

    return {
        "status": "success",
        "message": "File renamed successfully",
        "filename": db_file.original_filename
    }
@app.get("/files/frequently-used")
async def frequently_used_files(
    db: Session = Depends(get_db),
    current_user: dict = Depends(verify_user_token)
):
    cache_key = f"frequently_used:{current_user['username']}"

    # 1. Check Redis cache
    cached_data = redis_client.get(cache_key)

    if cached_data:
        print("Redis cache HIT")
        return json.loads(cached_data)

    # 2. Cache MISS → get data from SQLite
    print("Redis cache MISS")

    files = db.query(FileMetadata).filter(
        FileMetadata.owner == current_user["username"]
    ).order_by(
        FileMetadata.access_count.desc(),
        FileMetadata.last_accessed.desc()
    ).limit(10).all()

    result = [
        {
            "id": file.id,
            "filename": file.original_filename,
            "size": file.file_size_bytes,
            "uploaded_at": file.upload_time.isoformat() if file.upload_time else None,
            "access_count": file.access_count or 0,
            "last_accessed": file.last_accessed.isoformat()
            if file.last_accessed else None
        }
        for file in files
    ]

    # 3. Store result in Redis for 60 seconds
    redis_client.setex(
        cache_key,
        FREQUENT_FILES_CACHE_TTL,
        json.dumps(result)
    )

    print("Frequently used files cached in Redis")

    # 4. Return result
    return result