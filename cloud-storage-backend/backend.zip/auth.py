import hashlib
import secrets
from fastapi import Security, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

# OAuth2 bearer token scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def hash_password(password: str, salt: str = None) -> tuple:
    """
    Hashes a password securely using PBKDF2-HMAC-SHA256.
    Returns (hashed_hex_string, salt_hex_string).
    """
    if not salt:
        salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    ).hex()
    return hashed, salt

def verify_password(password: str, hashed: str, salt: str) -> bool:
    """
    Verifies a plain password against stored hash and salt using constant-time comparison.
    """
    if not hashed or not salt:
        return False
    new_hash, _ = hash_password(password, salt)
    return secrets.compare_digest(new_hash, hashed)

def hash_token(token_str: str) -> str:
    """
    Hashes a sensitive token or OTP using SHA-256 for secure storage.
    """
    return hashlib.sha256(token_str.encode('utf-8')).hexdigest()


def verify_user_token(token: str = Security(oauth2_scheme)):
    """
    Verifies the bearer token against active sessions in SQLite database.
    """
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    from database import SessionLocal, User, UserSession
    import datetime

    db = SessionLocal()
    try:
        session = db.query(UserSession).filter(
            UserSession.token == token,
            UserSession.expires_at > datetime.datetime.utcnow()
        ).first()

        if not session:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired authentication token",
                headers={"WWW-Authenticate": "Bearer"},
            )

        user = db.query(User).filter(User.username == session.username).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication token",
                headers={"WWW-Authenticate": "Bearer"},
            )

        return {"username": user.username, "email": user.email}
    finally:
        db.close()